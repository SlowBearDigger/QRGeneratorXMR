export const MY_XMR_ADDRESS = '42w9YaCW8UwZ2BmQztNmUd6JgYVcjW7LXEMTcQqHdmtFCsSo5RGY2eQg2iZ3WyBSSs63gnhczLkJ46yfr4ojCXWT3H1ZBbR';
export const DONATION_XMR_ADDRESS = '42w9YaCW8UwZ2BmQztNmUd6JgYVcjW7LXEMTcQqHdmtFCsSo5RGY2eQg2iZ3WyBSSs63gnhczLkJ46yfr4ojCXWT3H1ZBbR';
export const MONERO_ORANGE = '#F7B731';
export const TWITTER_HANDLE = 'SlowBearDigger';
export const TWITTER_SHARE_URL = 'https://twitter.com/intent/tweet';